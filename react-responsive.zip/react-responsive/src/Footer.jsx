function Footer(){
	return(
	<footer>
		<p>&copy; {new Date().getFullYear()} Afghan Goat Development</p>
	</footer>);
}
export default Footer